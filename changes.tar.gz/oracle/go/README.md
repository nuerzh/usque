# usque(重构版)

Cloudflare WARP 的非官方命令行客户端:使用 **MASQUE**(HTTP/3 CONNECT-IP,可回退到 HTTP/2)建立隧道,
并以 **SOCKS5** 或 **HTTP 代理**的形式暴露出来。无需 root,隧道跑在用户态网络栈(gVisor netstack)里。

这是对原项目的**结构性重写**:功能、命令行参数、`usque.json` 格式保持兼容,代码按职责重新分层。

## 功能

| 命令 | 作用 |
|---|---|
| `usque register` | 注册新设备并登记 MASQUE 密钥,写入配置文件 |
| `usque enroll` | 对已有账户重新登记密钥(或重新生成),刷新端点与隧道地址 |
| `usque socks` | 扫描可用端点 → 自动选优 → 启动 SOCKS5(CONNECT + UDP ASSOCIATE),断线自动切换/补池 |
| `usque http-proxy` | 固定端点、懒连接的 HTTP 代理(支持 CONNECT) |
| `usque nativetun` | 原生 TUN 网卡(Linux / Windows),承载整机的 IP 流量 |
| `usque l4-socks` / `l4-http-proxy` | 仅 TCP 的轻量代理:每条连接一个 HTTP/3 CONNECT 流,无用户态网络栈、无需特权 |
| `usque account info\|devices\|set\|reset` | 账户信息、设备列表、绑定/解绑 license |
| `usque route list\|sync\|test` | 查看/立即同步规则集;检查某个目标会走哪个出站 |
| `usque version` | 版本信息 |

`socks` 与 `http-proxy` 共有:**sing-box 风格的路由**(见下)。`socks` 专有能力:端点扫描(握手 + 隧道内 `/meta` + 突发探测筛掉被 DPI 中途切断的端点)、
A/B/C 三条选优规则、恢复轮次、Shadowsocks 链式落地。
各参数含义与原版一致,见 `usque <command> --help`。

## 构建

```sh
go mod tidy          # 首次:补全 go.sum 与间接依赖(新增依赖:songgao/water、vishvananda/netlink、sagernet/sing)
go build -ldflags "-s -w -X usque/internal/cli.version=v1.0.0" -o usque .
go test -race ./...
```

> 注意 ldflags 的变量路径已从 `.../cmd.version` 改为 `usque/internal/cli.version`(`goreleaser.yml` 已同步)。

## 架构

依赖方向自上而下,没有环,没有包级全局状态(原版有 `config.AppConfig` / `ConfigLoaded`、
`socks5.DialTCP` 等全局变量,靠 `init()` 与赋值传递)。

```
main.go ──► internal/cli        命令行、参数绑定、把各部件装配起来(自身不含网络逻辑)
              │
   ┌──────────┼──────────────┬───────────────┬──────────────┐
   ▼          ▼              ▼               ▼              ▼
 picker     tunnel        proxy/*          dialer         enroll
 选优规则   Supervisor    socks5           Dispatcher ──► route        注册流程
   │        保活/重连/转发 httpproxy        │  Direct       规则 + 规则集    │
   ▼          │              │             │  Tunnel       Syncer 定期同步  ▼
 scan         ▼              └─ netx.Dialer│  Shadowsocks                  cfapi
 探测器     masque                         ▼                               HTTP 客户端
   │        拨号 + TLS 公钥固定          resolver
   └──► endpoint(地址与池)   config(配置存取)   netx / socksaddr / logx(小工具)
```

| 包 | 职责 |
|---|---|
| `config` | `Config` 结构(JSON 兼容)、`Variant{HTTP2,IPv6}`、并发安全且**原子写入**的 `Store` |
| `cfapi` / `enroll` | Cloudflare API 客户端(可注入 BaseURL,便于测试)/ 纯函数式注册流程(不做磁盘 I/O) |
| `masque` | `Dialer.Dial` → `*Conn`;`Conn.Close()` 统一按序释放 CONNECT-IP/HTTP3/UDP socket |
| `tunnel` | `Supervisor`(状态机)+ `Selector` 接口(策略)+ `ResidentDevice`(常驻读协程,netstack 与原生 TUN 共用)+ `Hooks` |
| `nativetun` | 原生 TUN 设备:Linux(water + netlink)/ Windows(wintun + netsh)/ 其他平台明确报不支持 |
| `l4` | L4 代理:一个 `netx.Dialer`,复用一条 QUIC 连接,每个 TCP 连接一条 CONNECT 流 |
| `hooks` | 钩子脚本执行(直接 exec、不经 shell、输出转入日志),`tunnel` 与 `l4` 共用 |
| `scan` | `Scanner.Sample/Verify`:握手 → `/meta` → 突发探测 → 主机 ping;缓存挂在实例上而非全局 |
| `picker` | A/B/C 规则与恢复轮次;`Selector` 把它接到 `tunnel`;`ConfigPersister` 负责落盘 |
| `route` | 路由引擎:规则编译与匹配、`.srs`/JSON 规则集解析、`Syncer` 定期同步 |
| `dialer` | 四个出站(`Direct`、`Tunnel`、`Tunnel`+主机 DNS、`Shadowsocks`)与按决策分发的 `Dispatcher` |
| `proxy/socks5`, `proxy/httpproxy` | 自研协议实现,只依赖 `netx.Dialer` 接口 |

### 关键设计:策略与机制分离

原版 `api.MaintainTunnel` 一个函数接收 12 个配置项、同时处理"静态端点 / 端点池 / 候选通道 / 竞速 / 懒连接 / 切换",
状态散在多个局部变量里。现在:

* `tunnel.Supervisor` 只做机制:拨号 → 转发 → 失败或被要求切换 → 重连。
* `tunnel.Selector`(`Next / Failed / Better`)只做策略:去哪连。
  `http-proxy` 用 `StaticSelector`(一个固定地址),`socks` 用 `picker.Selector`(扫描驱动的池)。

## 重新登记密钥:`enroll`

`register` 已经会登记密钥;`enroll` 用于**对已有账户**重新登记:把旧设备迁移到新机器、账户从 WireGuard 切到 MASQUE、
或者隧道内地址变化(例如 ZeroTier 场景)后刷新配置。

```sh
usque enroll              # 重新登记配置里的现有密钥,刷新端点与地址
usque enroll -n my-box    # 同时给设备改名
usque enroll -r           # 重新生成密钥
```

API 若拒绝当前公钥,会提示是否重新生成(交互式确认;`-r` 则直接重新生成)。只更新端点、公钥、设备 ID 和隧道地址,
**访问令牌、端点池、`route`、`bypass_domains`、Shadowsocks 设置等一律保留**;API 返回的空字段不会覆盖已有值。
这与原版整份配置重写不同。

## 原生 TUN:`nativetun`

得到一块真实的网卡,可以承载任何 WARP 支持的 IP(L3)流量,也是最快的模式之一。

* **Linux**:需要 `tun.ko`、root 权限;地址/MTU/起网卡通过 netlink 完成(不再依赖 `ip` 命令)。
* **Windows**:需要把 [wintun.dll](https://www.wintun.net/) 放在 `usque.exe` 旁边,管理员权限;地址/MTU 通过 `netsh` 设置。
* 其他平台:命令存在,但会明确报"不支持"。

```sh
sudo usque nativetun                       # 出现 tun0(Windows 上是 usque)
sudo usque nativetun -n usque0 --persist   # 指定名称,退出后保留网卡(仅 Linux)
sudo usque nativetun -I                    # 只建网卡,MTU/地址/起网卡自己做(仅 Linux)
ping -I tun0 1.1.1.1
```

> **验证程度**:Linux 部分已在真实内核 TUN 上端到端测试。Windows 部分(`tun.CreateTUN` + `netsh`)**没有在 Windows 上运行过**:
> `netsh` 的命令序列有单元测试(与原版逐字一致),Windows 胶水代码只做过类型检查。请在目标机器上先试用。

**程序不会设置任何路由,也不改 DNS**。要把全部流量导入隧道,需要先让到 MASQUE 端点的流量走原网卡
(端点地址见配置里的 `endpoint_v4`),再改默认路由;最方便的做法是用钩子:

```sh
sudo usque nativetun --on-connect /etc/usque/up.sh --on-disconnect /etc/usque/down.sh
```

```sh
#!/bin/sh   # /etc/usque/up.sh
set -e
ip route replace 162.159.198.1/32 via 192.168.1.1 dev eth0   # 端点走原网卡
ip route replace default dev "$USQUE_IFACE"
echo "nameserver 1.1.1.1" > /etc/resolv.conf
```

钩子直接 exec(不经 shell、不带参数),后台运行不会卡住隧道,输出按行转入日志(`hook[connect]` / `hook[disconnect]`)。
环境变量:`USQUE_EVENT`(`connect`/`disconnect`)、`USQUE_MODE`(`nativetun`/`socks`/`http-proxy`/`l4-socks`/`l4-http-proxy`)、
`USQUE_IFACE`(仅 nativetun)、`USQUE_IPV4`、`USQUE_IPV6`、`USQUE_ENDPOINT`(隧道模式)、`USQUE_TARGET`(仅 L4:当前连接的目标)。

空闲时不连接:没有出站流量就不建立隧道,第一个出站包会唤醒它(并且**该包会在连上后被转发**,不需要等重传);
`--always-reconnect` 则始终保持连接。

> 该命令的 `-s` 默认 SNI 是 `consumer-masque.cloudflareclient.com`(沿用原版);`socks` / `http-proxy` 沿用此前分叉版本的
> `engage.cloudflareclient.com`。两者都可以用 `-s` 覆盖。

## L4 代理:`l4-socks` / `l4-http-proxy`

只做 TCP,但更轻:每个被代理的 TCP 连接对应**一条 HTTP/3 CONNECT 流**,共用一条 QUIC 连接,没有 IP 隧道、没有用户态网络栈、不需要特权,跨平台。
SOCKS5 的 UDP ASSOCIATE 会被明确拒绝("命令不支持")。

```sh
usque l4-socks      -p 1080
usque l4-http-proxy -p 8000 -u user -w pass
```

* `-l`(默认开启)先在本机解析主机名,端点只会看到 IP;`-l=false` 则把主机名原样交给端点;`--system-dns` 用系统解析器,否则用 `-d`。
* 使用专用 SNI `consumer-masque-proxy.cloudflareclient.com`;仅 HTTP/3,没有 `--http2`。
* QUIC 连接失效(断网、被对端关闭)后,下一个连接会自动重建;并发连接共用同一条 QUIC 连接。
* L4 代理**不经过路由引擎**:它本来就是"所有 TCP 都走 MASQUE 端点"。需要分流请用 `socks` / `http-proxy`。
* `--on-connect` / `--on-disconnect` 对**每个 CONNECT 流**触发,带 `USQUE_TARGET`。

## 路由

四种出站(`outbound`):

| 出站 | 连接走哪里 | DNS 谁来解析 |
|---|---|---|
| `direct` | **不经过隧道**,走本机网络 | 本机(默认系统解析器;配置了 `local_dns` 则用它) |
| `dnsdirect` | 经过隧道 | **本机**(不经过隧道):`local_dns`,否则 `--system-dns`,否则 `-d` |
| `tunnel` | 全部经过隧道 | 隧道内 |
| `upstream` | 经过隧道,再经 Shadowsocks(`landing_ss*`) | 由 Shadowsocks 服务器 |

规则语义同 sing-box:**自上而下,第一条命中的生效**,都不命中走 `final`(默认 `tunnel`)。
同一条规则里,不同种类的条件取 **AND**,同一种类里的多个值取 **OR**
(`domain`/`domain_suffix`/`domain_keyword`/`domain_regex` 算一种,`port`/`port_range` 算一种)。
`invert` 对整条规则的结果取反;`"type":"logical"` + `"mode":"and"|"or"` 可嵌套组合。

支持的条件:`network`、`domain`、`domain_suffix`、`domain_keyword`、`domain_regex`、`ip_cidr`、
`port`、`port_range`、`rule_set`、`invert`。规则集里出现的其他条件(进程名、源地址、WiFi 等,
代理场景无法判断)会让**该条规则永不命中**,并在日志里提示,而不是只按其中一部分条件放行。

**`resolve` 动作**(同 sing-box):`{"action":"resolve"}` 不是终止规则,它解析目标域名,
之后的 `ip_cidr` 规则(例如 geoip)才能匹配域名目标;解析失败则 IP 规则不命中。
解析结果带 5 分钟缓存;同一连接内只解析一次。`route.resolver` 选择谁来解析:
`system`(默认)、`local`(`local_dns` / `-d`)、`tunnel`。命中 `direct`/`dnsdirect` 时直接拨号该 IP,
保证连接去的就是规则看到的地址。

完整示例见 [`route.example.json`](route.example.json)(CN 域名/IP 直连、局域网直连、指定站点走 Shadowsocks、其余走隧道)。

### 规则集与定期同步

`rule_set` 与 sing-box 一致:`tag`、`type`(`remote`/`local`)、`format`(`binary` 即 `.srs`,或 `source` 即 `.json`;
缺省按扩展名、再按内容判断)、`url`、`path`、`update_interval`(`"1d"`、`"12h"`……默认 1 天,最短 1 分钟)。
另有 `download_detour`:`direct`(默认,本机下载)或 `tunnel`(通过隧道下载)。

同步机制:

* 启动时先读磁盘缓存(`route.cache_dir`,默认配置文件旁的 `rule_set/`);没有缓存的远程规则集会在监听端口**之前**并行下载(最多等 15 秒),失败不影响启动。
* 之后每个远程规则集按 `update_interval` 刷新,使用 `ETag` / `Last-Modified` 条件请求,没变化就不重复下载。
* **先校验、再替换**:下载内容必须能被完整解析并编译,才会原子地换入内存并写入缓存;内容无效(例如 CDN 返回 200 的错误页)、网络失败、超大文件(>64 MiB)都不会影响正在使用的规则。
* 失败后按 1m、2m、4m……(上限 1 小时且不超过更新间隔)退避重试,恢复后回到正常周期。
* `local` 规则集每 30 秒检查文件修改时间,变化则热加载;写坏了保留上一份可用规则。

命令:

```sh
usque route list                 # 规则集与缓存状态
usque route sync [--force]       # 立即下载(--force 忽略 ETag)
usque route test www.baidu.com   # 这个目标会走哪个出站、命中第几条规则
usque socks --route-log          # 每个连接记录一行路由决策
```

### 与旧配置的兼容

没有 `route` 段时,按旧字段推导出等价的路由表,**行为不变**:`bypass_domains` 里的域名后缀/IP/CIDR
→ `dnsdirect`;其余 → 配了 `landing_ss` 则 `upstream`,否则 `tunnel`(`-l` 且无 bypass 时为 `dnsdirect`)。
`http-proxy` 沿用原行为(不用 `bypass_domains`/Shadowsocks),只有显式写了 `route` 才启用路由;
此时 `upstream` 使用配置里的 `landing_ss*`。写了 `route` 后,`bypass_domains` 与 `-l` 不再参与决策。

启动时会静态检查整张路由表:未知出站、未定义的规则集、非法正则/CIDR/端口范围、拼错的字段名(如 `domain_sufix`)、
`upstream` 但没配 Shadowsocks——都会直接报错退出,而不是运行时悄悄走错路。

## 与原版的有意差异

行为改进(均有测试覆盖):

1. **SOCKS5 自研**,去掉 `txthinking/socks5`、`runnergroup`、`go-cache` 三个依赖;UDP ASSOCIATE 每个关联独立 socket、
   按目标建 flow、双向活动都刷新空闲计时、并发 flow 数上限 256、只接受握手客户端 IP(及声明的端口)的数据报。
2. **HTTP 代理**:不再把 `Proxy-Authorization` 转发给源站;不再自动跟随 30x 重定向(代理应原样透传);
   复用单个 `Transport` 而不是每请求新建;凭据用常量时间比较。
3. **懒连接**时,唤醒隧道的那个首包不再被丢弃,而是在连上后转发(原版需等 TCP 重传)。
4. **配置文件**原子写入(临时文件 + rename),权限 0600;原版直接截断重写,崩溃会损坏文件。
5. **拨号超时**:出站拨号默认 30s、端点竞速 15s;原版对隧道内拨号没有超时。
6. **优雅退出**:Ctrl+C / SIGTERM 取消全部协程(原版刻意不处理信号);`Supervisor` 在 ctx 取消时能立即停止转发协程。
7. 解析 DNS 时按**隧道实际拥有的地址族**挑选结果(隧道无 IPv6 时不再返回 AAAA 地址);并行查询时用 `DialContext`,可被取消。
8. 缺 IPv4 或 IPv6 的账户配置不再报"无效 IP";注册返回无 peers 时报错而不是 panic。
9. 新增路由引擎(见上),`bypass_domains` 的实现并入其中:此前它在 DNS/链/直连之间有 4 组重复分支。
10. `nativetun`:创建失败返回错误而不是 `log.Fatalf`;`Open` 失败时清理已建的网卡;读取协程常驻,取消读取不会吞掉下一个包;Linux 地址设置经 `linkOps` 接口,时序可单测。
11. `l4`:新增 `Close()`;出站拨号可取消;`CONNECT` 缺端口时默认 443(HTTP 代理)。
12. 删除死代码:`utils_windows.go`(netsh)、`CheckIfname`、`ZeroTierSNI` 等无调用者的部分。

**未移植**:原版的 `portfw`(端口转发)不在本次范围内。

保持不变:全部子命令与参数名/短参数/默认值、`usque.json` 字段、选优规则与恢复轮次语义、
钩子环境变量(`USQUE_MODE/EVENT/ENDPOINT/IPV4/IPV6`)、扫描算法与参数。

## 测试

`go test -race ./...`(覆盖所有包)。重点:

* `internal/route`:用**官方发布的真实 `.srs` 文件**(`testdata/`,geosite-cn 等)校验解析器,
  另覆盖各类条目、逻辑规则与 `invert`、畸形/截断/随机损坏输入;同步器用 `httptest` 验证条件请求、
  失败保留旧规则、退避重试、定时刷新、本地文件热加载。
* `internal/nativetun`:Linux 上用**真实的内核 TUN 设备**测试(需要 root 和 `/dev/net/tun`,否则自动跳过):核对 MTU/地址/状态、双向收发 IP 包、`--persist`、`-I`,
  以及**内核 ping 经 TUN → MASQUE 隧道 → 本地模拟端点原路返回**;`netsh` 命令序列在所有平台上按字符串断言。
* `internal/l4`、`internal/cli`:用进程内的真实 QUIC/HTTP3 CONNECT 端点,整机测试 `l4-socks`/`l4-http-proxy`/`nativetun`/`enroll` 命令(含配置里的公钥固定、认证、钩子环境变量)。
* `internal/tunnel/integration_test.go`:在进程内起一个 HTTP/3 CONNECT-IP 服务端(应答 ICMP echo),
  用**真实的** `masque.Dialer` + `Supervisor` + netstack 端到端验证:公钥固定(错误密钥被拒)、
  断线自动重连、懒连接首包转发、切换到更优端点且不记为失败、ctx 取消后干净退出。

## 许可

MIT,沿用原项目(`LICENSE.md`)。

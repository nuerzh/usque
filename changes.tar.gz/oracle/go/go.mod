module usque

go 1.26.3

require (
	github.com/Diniboy1123/connect-ip-go v0.0.0-20260613064811-66cba32d7d33
	github.com/quic-go/quic-go v0.60.0
	github.com/sagernet/sing v0.0.0-20260929150544-6f21f2425a95
	github.com/shadowsocks/go-shadowsocks2 v0.1.5
	github.com/songgao/water v0.0.0-20200317203138-2b4b6d7c09d8
	github.com/spf13/cobra v1.10.2
	github.com/vishvananda/netlink v1.3.1
	github.com/yosida95/uritemplate/v3 v3.0.2
	golang.org/x/net v0.56.0
	golang.zx2c4.com/wireguard v0.0.0-20260522210424-ecfc5a8d5446
	gvisor.dev/gvisor v0.0.0-20260616165937-8e4bc62602eb
)

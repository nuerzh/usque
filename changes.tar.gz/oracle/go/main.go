package main

import (
	"fmt"
	"os"

	"usque/internal/cli"
	"usque/internal/logx"
)

func main() {
	logx.Install()
	if err := cli.Execute(); err != nil {
		fmt.Fprintln(os.Stderr, "Error:", err)
		os.Exit(1)
	}
}

//! Endpoint selection rules A, B and C over scan rounds, ported from the Go
//! usque `internal/picker`. This module is a pure state machine: no I/O, no
//! tasks, no time reads.
//!
//! An endpoint's latency is its steady in-tunnel round trip when measured;
//! unknown sorts last. Three rules apply on top of probe results:
//!
//!   - A (immediate adopt): while a round is probing, the first working
//!     endpoint at or below the threshold is adopted at once. During a
//!     recovery round the threshold is dropped: after a disconnect any
//!     survivor is adopted and rule B upgrades it later.
//!   - B (switch): when a round ends, a result strictly better than the
//!     endpoint in use replaces it; equal or worse keeps the connection.
//!   - C (first pick): when a round ends with nothing in use, the lowest
//!     latency result is adopted.
use std::net::SocketAddr;
use std::time::Duration;

use usque_core::Transport;

/// Rule A adopts the first working endpoint whose steady in-tunnel round trip
/// is at or below this value.
pub(crate) const DEFAULT_THRESHOLD: Duration = Duration::from_millis(190);

/// One persistent pool variant. CONNECT-IP and L4 handshake endpoints are
/// separate services: a candidate that serves one need not serve the other.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(crate) enum PoolKey {
    ConnectIp(Transport),
    L4,
}

impl PoolKey {
    pub(crate) const ALL: [PoolKey; 3] = [
        PoolKey::ConnectIp(Transport::Http3),
        PoolKey::ConnectIp(Transport::Http2),
        PoolKey::L4,
    ];

    pub(crate) const fn index(self) -> usize {
        match self {
            PoolKey::ConnectIp(Transport::Http3) => 0,
            PoolKey::ConnectIp(Transport::Http2) => 1,
            PoolKey::L4 => 2,
        }
    }

    pub(crate) const fn file_key(self) -> &'static str {
        match self {
            PoolKey::ConnectIp(Transport::Http3) => "connect_ip_h3",
            PoolKey::ConnectIp(Transport::Http2) => "connect_ip_h2",
            PoolKey::L4 => "l4",
        }
    }

    pub(crate) const fn transport(self) -> Transport {
        match self {
            PoolKey::ConnectIp(transport) => transport,
            PoolKey::L4 => Transport::Http3,
        }
    }

    pub(crate) fn from_file_key(key: &str) -> Option<PoolKey> {
        match key {
            "connect_ip_h3" => Some(PoolKey::ConnectIp(Transport::Http3)),
            "connect_ip_h2" => Some(PoolKey::ConnectIp(Transport::Http2)),
            "l4" => Some(PoolKey::L4),
            _ => None,
        }
    }
}

/// One probed endpoint. `measured` reports whether the steady in-tunnel round
/// trip (`tun_ping`) and `loss` were sampled by the durability burst.
#[derive(Clone, Debug, PartialEq)]
pub(crate) struct MeasuredEndpoint {
    pub(crate) endpoint: SocketAddr,
    pub(crate) colo: Option<String>,
    pub(crate) loss: f32,
    pub(crate) tun_ping: Option<Duration>,
    pub(crate) conn: Option<Duration>,
    pub(crate) measured: bool,
}

impl MeasuredEndpoint {
    pub(crate) fn unmeasured(endpoint: SocketAddr) -> Self {
        Self {
            endpoint,
            colo: None,
            loss: 0.0,
            tun_ping: None,
            conn: None,
            measured: false,
        }
    }

    /// The figure used for thresholds and ranking: the steady in-tunnel round
    /// trip when sampled, unknown otherwise. Host ICMP is not probed.
    pub(crate) fn latency(&self) -> Option<Duration> {
        if self.measured {
            self.tun_ping.filter(|round_trip| !round_trip.is_zero())
        } else {
            None
        }
    }
}

/// Whether `candidate` is strictly preferable to `current`: unknown never
/// improves on a known value, and a known value always beats unknown.
pub(crate) fn better(candidate: Option<Duration>, current: Option<Duration>) -> bool {
    match candidate {
        Some(candidate) => current.is_none_or(|current| candidate < current),
        None => false,
    }
}

/// The endpoint with the lowest known latency, keeping the first entry when
/// all latencies are unknown.
pub(crate) fn lowest(list: &[MeasuredEndpoint]) -> Option<&MeasuredEndpoint> {
    let mut best = list.first()?;
    for endpoint in &list[1..] {
        if better(endpoint.latency(), best.latency()) {
            best = endpoint;
        }
    }
    Some(best)
}

/// Loss first, then known latency, then address: the scan round's ranking.
fn ranked_before(a: &MeasuredEndpoint, b: &MeasuredEndpoint) -> bool {
    if a.loss != b.loss {
        return a.loss < b.loss;
    }
    match (a.latency(), b.latency()) {
        (Some(left), Some(right)) if left != right => left < right,
        // Loss is only meaningful on a measured endpoint, so unmeasured ones
        // carry loss 0; Go's rank still sorts them after measured latency.
        (Some(_), None) => true,
        (None, Some(_)) => false,
        (None, None) => a.endpoint < b.endpoint,
        _ => a.endpoint < b.endpoint,
    }
}

fn rank_order(left: &MeasuredEndpoint, right: &MeasuredEndpoint) -> std::cmp::Ordering {
    if ranked_before(left, right) {
        std::cmp::Ordering::Less
    } else {
        std::cmp::Ordering::Greater
    }
}

/// Every endpoint a scan reported as working, minus the ones that failed
/// since. Dropping the last survivor falls back to the full set so a
/// transient outage cannot strand the pool.
#[derive(Debug, Default)]
pub(crate) struct EndpointPool {
    all: Vec<MeasuredEndpoint>,
    alive: Vec<MeasuredEndpoint>,
}

impl EndpointPool {
    pub(crate) fn alive(&self) -> &[MeasuredEndpoint] {
        &self.alive
    }

    pub(crate) fn all(&self) -> &[MeasuredEndpoint] {
        &self.all
    }

    pub(crate) fn merge(&mut self, endpoint: MeasuredEndpoint) {
        if let Some(known) = self
            .all
            .iter_mut()
            .find(|known| known.endpoint == endpoint.endpoint)
        {
            *known = endpoint.clone();
        } else {
            self.all.push(endpoint.clone());
        }
        if let Some(known) = self
            .alive
            .iter_mut()
            .find(|known| known.endpoint == endpoint.endpoint)
        {
            *known = endpoint;
        } else {
            self.alive.push(endpoint);
        }
    }

    pub(crate) fn drop_addr(&mut self, addr: SocketAddr) {
        self.alive.retain(|known| known.endpoint != addr);
        if self.alive.is_empty() && !self.all.is_empty() {
            self.alive = self.all.clone();
        }
    }

    /// Seeds a pool restored from disk: the addresses are dialable but their
    /// metrics are unknown until the next round re-verifies them.
    pub(crate) fn restore(&mut self, addrs: impl IntoIterator<Item = SocketAddr>) {
        for addr in addrs {
            if self.all.iter().any(|known| known.endpoint == addr) {
                continue;
            }
            let endpoint = MeasuredEndpoint::unmeasured(addr);
            self.all.push(endpoint.clone());
            self.alive.push(endpoint);
        }
    }
}

/// Whether the caller should start a scan round.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(crate) enum RoundKind {
    Startup,
    Recovery,
}

#[derive(Debug, Default)]
struct VariantState {
    pool: EndpointPool,
    running: bool,
    recovering: bool,
    in_use: Option<MeasuredEndpoint>,
}

/// The A/B/C state machine: one pool variant per (mode, transport).
pub(crate) struct Picker {
    threshold: Duration,
    variants: [VariantState; PoolKey::ALL.len()],
}

impl Picker {
    pub(crate) fn new(threshold: Duration) -> Self {
        Self {
            threshold,
            variants: std::array::from_fn(|_| VariantState::default()),
        }
    }

    pub(crate) fn pool(&self, key: PoolKey) -> &EndpointPool {
        &self.variants[key.index()].pool
    }

    /// Seeds one variant from persisted endpoints: dialable, unmeasured, and
    /// re-verified by the next round.
    pub(crate) fn restore(&mut self, key: PoolKey, addrs: impl IntoIterator<Item = SocketAddr>) {
        self.variants[key.index()].pool.restore(addrs);
    }

    /// Registers the endpoint a successful connection used, as the baseline
    /// rule B compares against. A race winner is unmeasured until a round
    /// samples it; it still joins the pool so a recovery round re-verifies
    /// it like any other known endpoint.
    pub(crate) fn note_connected(&mut self, key: PoolKey, endpoint: SocketAddr) {
        let state = &mut self.variants[key.index()];
        let known = state
            .pool
            .all()
            .iter()
            .find(|known| known.endpoint == endpoint)
            .cloned()
            .unwrap_or_else(|| MeasuredEndpoint::unmeasured(endpoint));
        state.pool.merge(known.clone());
        state.in_use = Some(known);
    }

    /// Drops an endpoint that failed as a switch candidate without touching
    /// the connection in use.
    pub(crate) fn drop_candidate(&mut self, key: PoolKey, endpoint: SocketAddr) {
        self.variants[key.index()].pool.drop_addr(endpoint);
    }

    /// The session in use died: forget it, drop it from the pool and mark the
    /// variant for a recovery round.
    pub(crate) fn session_failed(&mut self, key: PoolKey) {
        let state = &mut self.variants[key.index()];
        if let Some(current) = state.in_use.take() {
            state.pool.drop_addr(current.endpoint);
        }
        state.recovering = true;
    }

    /// Opens a scan round unless one is in flight. A recovery round re-verifies
    /// what the pool already knows before sampling the pools again.
    pub(crate) fn begin_round(&mut self, key: PoolKey) -> Option<RoundKind> {
        let state = &mut self.variants[key.index()];
        if state.running {
            return None;
        }
        state.running = true;
        Some(if state.recovering {
            RoundKind::Recovery
        } else {
            RoundKind::Startup
        })
    }

    /// Probe callback: feeds the live pool and applies rule A. Returns the
    /// address to adopt immediately, when rule A fires.
    pub(crate) fn on_working(
        &mut self,
        key: PoolKey,
        endpoint: MeasuredEndpoint,
    ) -> Option<SocketAddr> {
        let state = &mut self.variants[key.index()];
        state.pool.merge(endpoint.clone());
        if state.in_use.is_some() {
            return None;
        }
        // A recovery round drops the threshold: a disconnect trades optimality
        // for availability, and rule B upgrades the connection when the round
        // settles. Rule A adopts a measured endpoint at or below the threshold.
        if !state.recovering
            && !endpoint
                .latency()
                .is_some_and(|latency| latency <= self.threshold)
        {
            return None;
        }
        state.in_use = Some(endpoint.clone());
        Some(endpoint.endpoint)
    }

    /// Merges a batch of round results and applies rules B and C without
    /// closing the round: a recovery round settles its first phase while the
    /// sample phase is still open.
    pub(crate) fn settle(
        &mut self,
        key: PoolKey,
        results: &[MeasuredEndpoint],
    ) -> Option<SocketAddr> {
        let state = &mut self.variants[key.index()];
        for endpoint in results {
            state.pool.merge(endpoint.clone());
        }
        let best = lowest(results)?;
        let adopted = match state.in_use.as_ref() {
            Some(current) if better(best.latency(), current.latency()) => true,
            Some(_) => false,
            None => true,
        };
        if !adopted {
            return None;
        }
        let best = best.clone();
        state.in_use = Some(best.clone());
        Some(best.endpoint)
    }

    /// Closes the round: settle applies rules B and C, then the round is marked
    /// finished so the next failure may start a recovery.
    pub(crate) fn end_round(
        &mut self,
        key: PoolKey,
        results: &[MeasuredEndpoint],
    ) -> Option<SocketAddr> {
        let adopted = self.settle(key, results);
        let state = &mut self.variants[key.index()];
        state.running = false;
        state.recovering = false;
        adopted
    }

    /// Live candidates ranked for a fresh connection: loss, then known
    /// latency, then address.
    pub(crate) fn suggest(&self, key: PoolKey) -> Vec<SocketAddr> {
        let mut alive = self.variants[key.index()].pool.alive().to_vec();
        alive.sort_by(|left, right| rank_order(left, right));
        alive
            .into_iter()
            .map(|endpoint| endpoint.endpoint)
            .collect()
    }

    /// Known endpoints in rank order, capped for bounded recovery rounds.
    pub(crate) fn known(&self, key: PoolKey, cap: usize) -> Vec<SocketAddr> {
        let mut all = self.variants[key.index()].pool.all().to_vec();
        all.sort_by(|left, right| rank_order(left, right));
        all.into_iter()
            .take(cap)
            .map(|endpoint| endpoint.endpoint)
            .collect()
    }

    /// Everything the pools learned, for persistence.
    pub(crate) fn snapshot(&self) -> Vec<(PoolKey, SocketAddr)> {
        let mut snapshot = Vec::new();
        for key in PoolKey::ALL {
            snapshot.extend(
                self.pool(key)
                    .alive()
                    .iter()
                    .map(|endpoint| (key, endpoint.endpoint)),
            );
        }
        snapshot
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn addr(last: u8) -> SocketAddr {
        format!("162.159.199.{last}:443").parse().unwrap()
    }

    fn working(endpoint: SocketAddr, tun_ping: Duration, loss: f32) -> MeasuredEndpoint {
        MeasuredEndpoint {
            endpoint,
            colo: Some("SJC".to_owned()),
            loss,
            tun_ping: Some(tun_ping),
            conn: Some(tun_ping * 2),
            measured: true,
        }
    }

    fn unmeasured(endpoint: SocketAddr) -> MeasuredEndpoint {
        MeasuredEndpoint::unmeasured(endpoint)
    }

    fn in_use(picker: &Picker, key: PoolKey) -> Option<SocketAddr> {
        picker.variants[key.index()]
            .in_use
            .as_ref()
            .map(|endpoint| endpoint.endpoint)
    }

    const H3: PoolKey = PoolKey::ConnectIp(Transport::Http3);

    #[test]
    fn rule_a_adopts_the_first_endpoint_at_or_below_the_threshold() {
        let mut picker = Picker::new(DEFAULT_THRESHOLD);
        assert_eq!(
            picker.on_working(H3, working(addr(1), Duration::from_millis(190), 0.0)),
            Some(addr(1)),
        );
        assert_eq!(
            picker.on_working(H3, working(addr(2), Duration::from_millis(120), 0.0)),
            None,
            "an endpoint already in use is not replaced mid-round",
        );
    }

    #[test]
    fn rule_a_rejects_slow_and_unmeasured_results_outside_recovery() {
        let mut picker = Picker::new(DEFAULT_THRESHOLD);
        assert_eq!(
            picker.on_working(H3, working(addr(1), Duration::from_millis(400), 0.0)),
            None,
        );
        assert_eq!(picker.on_working(H3, unmeasured(addr(2))), None);
        assert!(
            !picker.pool(H3).alive().is_empty(),
            "the pool still records both"
        );
        assert_eq!(in_use(&picker, H3), None);
    }

    #[test]
    fn a_recovery_round_drops_the_threshold_and_adopts_any_survivor() {
        let mut picker = Picker::new(DEFAULT_THRESHOLD);
        let key = picker.begin_round(H3).expect("startup round");
        assert_eq!(key, RoundKind::Startup);
        picker.end_round(H3, &[]);
        picker.session_failed(H3);
        let next = picker.begin_round(H3);
        assert!(matches!(next, Some(RoundKind::Recovery)));
        assert_eq!(picker.on_working(H3, unmeasured(addr(3))), Some(addr(3)));
    }

    #[test]
    fn a_failure_while_a_round_is_in_flight_only_marks_it_for_recovery() {
        let mut picker = Picker::new(DEFAULT_THRESHOLD);
        picker.begin_round(H3).expect("startup round");
        picker.session_failed(H3);
        assert!(
            picker.begin_round(H3).is_none(),
            "the in-flight round finishes first; the next failure opens the recovery",
        );
    }

    #[test]
    fn rule_b_switches_only_to_a_strictly_better_result() {
        let mut picker = Picker::new(DEFAULT_THRESHOLD);
        picker.note_connected(H3, addr(1));
        let results = [
            working(addr(2), Duration::from_millis(150), 0.0),
            working(addr(3), Duration::from_millis(80), 0.0),
        ];
        assert_eq!(picker.settle(H3, &results), Some(addr(3)));
        assert_eq!(in_use(&picker, H3), Some(addr(3)));

        let worse = [working(addr(2), Duration::from_millis(150), 0.0)];
        assert_eq!(picker.settle(H3, &worse), None);
        assert_eq!(in_use(&picker, H3), Some(addr(3)));

        let equal = [working(addr(4), Duration::from_millis(80), 0.0)];
        assert_eq!(
            picker.settle(H3, &equal),
            None,
            "equal latency keeps the connection"
        );
    }

    #[test]
    fn rule_b_adopts_a_measured_result_over_an_unmeasured_connection_in_use() {
        let mut picker = Picker::new(DEFAULT_THRESHOLD);
        picker.note_connected(H3, addr(1));
        let results = [working(addr(2), Duration::from_millis(900), 0.0)];
        assert_eq!(picker.settle(H3, &results), Some(addr(2)));
    }

    #[test]
    fn rule_c_adopts_the_lowest_latency_when_nothing_is_in_use() {
        let mut picker = Picker::new(DEFAULT_THRESHOLD);
        let results = [
            working(addr(1), Duration::from_millis(200), 0.0),
            working(addr(2), Duration::from_millis(40), 0.0),
            unmeasured(addr(3)),
        ];
        assert_eq!(picker.settle(H3, &results), Some(addr(2)));
        assert_eq!(in_use(&picker, H3), Some(addr(2)));
        assert_eq!(picker.settle(H3, &[]), None);
    }

    #[test]
    fn a_failed_endpoint_is_dropped_and_the_pool_falls_back_when_emptied() {
        let mut picker = Picker::new(DEFAULT_THRESHOLD);
        picker.on_working(H3, working(addr(1), Duration::from_millis(50), 0.0));
        picker.on_working(H3, working(addr(2), Duration::from_millis(60), 0.0));
        picker.session_failed(H3);
        assert_eq!(
            picker.pool(H3).alive().len(),
            1,
            "the endpoint in use is dropped"
        );
        {
            let state = &mut picker.variants[H3.index()];
            state.pool.drop_addr(addr(2));
            assert_eq!(
                state.pool.alive().len(),
                2,
                "an emptied pool falls back to every endpoint it ever knew",
            );
        }
    }

    #[test]
    fn merging_a_fresh_probe_revives_a_dropped_endpoint() {
        let mut pool = EndpointPool::default();
        pool.merge(working(addr(1), Duration::from_millis(50), 0.0));
        pool.merge(working(addr(2), Duration::from_millis(60), 0.0));
        pool.drop_addr(addr(1));
        assert_eq!(pool.alive().len(), 1);
        pool.merge(working(addr(1), Duration::from_millis(45), 0.0));
        assert_eq!(pool.alive().len(), 2);
        assert_eq!(pool.all().len(), 2);
    }

    #[test]
    fn suggest_ranks_by_loss_then_latency_then_address() {
        let mut picker = Picker::new(DEFAULT_THRESHOLD);
        picker.restore(H3, [addr(9)]);
        picker.on_working(H3, unmeasured(addr(5)));
        picker.on_working(H3, working(addr(3), Duration::from_millis(300), 0.0));
        picker.on_working(H3, working(addr(4), Duration::from_millis(120), 0.0));
        picker.on_working(H3, working(addr(2), Duration::from_millis(120), 0.5));
        assert_eq!(
            picker.suggest(H3),
            vec![addr(4), addr(3), addr(5), addr(9), addr(2)],
            "loss first (unmeasured counts as 0), then latency, then address",
        );
    }

    #[test]
    fn a_round_can_only_start_when_none_is_in_flight() {
        let mut picker = Picker::new(DEFAULT_THRESHOLD);
        assert!(picker.begin_round(H3).is_some());
        assert!(picker.begin_round(H3).is_none());
        picker.end_round(H3, &[]);
        assert!(picker.begin_round(H3).is_some());
    }

    #[test]
    fn end_round_clears_the_recovery_state() {
        let mut picker = Picker::new(DEFAULT_THRESHOLD);
        picker.begin_round(H3).expect("startup round");
        picker.session_failed(H3);
        picker.end_round(H3, &[working(addr(1), Duration::from_millis(70), 0.0)]);
        assert_eq!(
            picker.on_working(H3, working(addr(2), Duration::from_millis(180), 0.0)),
            None,
            "outside recovery the threshold applies again"
        );
    }

    #[test]
    fn snapshot_reports_every_variant_alive_endpoint() {
        let mut picker = Picker::new(DEFAULT_THRESHOLD);
        picker.on_working(H3, working(addr(1), Duration::from_millis(70), 0.0));
        picker.on_working(PoolKey::ConnectIp(Transport::Http2), unmeasured(addr(2)));
        picker.on_working(PoolKey::L4, unmeasured(addr(3)));
        assert_eq!(picker.snapshot().len(), 3);
    }

    #[test]
    fn file_keys_round_trip() {
        for key in PoolKey::ALL {
            assert_eq!(PoolKey::from_file_key(key.file_key()), Some(key));
        }
        assert_eq!(PoolKey::from_file_key("bogus"), None);
    }

    #[test]
    fn better_never_prefers_an_unknown_value() {
        let slow = Some(Duration::from_secs(5));
        assert!(better(Some(Duration::from_millis(1)), slow));
        assert!(!better(None, Some(Duration::from_millis(1))));
        assert!(!better(None, None));
        assert!(better(Some(Duration::from_millis(1)), None));
        assert!(!better(slow, slow));
    }

    #[test]
    fn lowest_keeps_the_first_entry_when_all_latencies_are_unknown() {
        let endpoints = [unmeasured(addr(1)), unmeasured(addr(2))];
        assert_eq!(
            lowest(&endpoints).map(|endpoint| endpoint.endpoint),
            Some(addr(1))
        );
        assert_eq!(lowest(&[]), None);
    }
}

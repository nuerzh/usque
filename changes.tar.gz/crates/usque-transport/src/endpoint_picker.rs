//! The shared endpoint picker: runs scan rounds against a mode's prober and
//! feeds the results into the A/B/C rules ([`crate::picker::Picker`]).
//!
//! Rounds run in the background: `ensure_round` starts one when the variant
//! is idle (startup right after a connection begins, recovery after a
//! failure). Rule A/B/C decisions surface as a single recommendation that
//! the connection code consumes exactly once.
use std::collections::BTreeMap;
use std::path::{Path, PathBuf};
use std::sync::{Arc, Mutex};

use tokio::sync::watch;
use tokio_util::sync::CancellationToken;

use crate::picker::{DEFAULT_THRESHOLD, Picker, PoolKey, RoundKind};
use crate::scan::{self, ScanOptions, ScanProber};

/// Recovery rounds re-verify what the pools already know first; the cap keeps
/// a long-lived pool's round bounded.
const RECOVERY_VERIFY_CAP: usize = 48;

/// A pool key paired with the endpoint the picker wants in use.
pub(crate) type Recommendation = (PoolKey, std::net::SocketAddr);

/// The runtime handle shared by the connection supervisor and the scan
/// rounds.
pub(crate) struct EndpointPicker {
    picker: Mutex<Picker>,
    recommendation: watch::Sender<Option<Recommendation>>,
    prober: Arc<dyn ScanProber>,
    store_path: Option<PathBuf>,
    options: ScanOptions,
    cancellation: CancellationToken,
}

impl EndpointPicker {
    pub(crate) fn new(
        prober: Arc<dyn ScanProber>,
        store_path: Option<PathBuf>,
        options: ScanOptions,
        cancellation: CancellationToken,
    ) -> Arc<Self> {
        let mut picker = Picker::new(DEFAULT_THRESHOLD);
        if let Some(path) = store_path.as_deref() {
            for (key, endpoint) in load_store(path) {
                picker.restore(key, [endpoint]);
            }
        }
        Arc::new(Self {
            picker: Mutex::new(picker),
            recommendation: watch::channel(None).0,
            prober,
            store_path,
            options,
            cancellation,
        })
    }

    /// Builds the CONNECT-IP picker that scans through a throwaway MASQUE
    /// tunnel for one profile identity.
    pub(crate) fn for_connection(
        profile: &usque_core::Profile,
        identity: &crate::h2::MasqueTlsIdentity,
        protector: std::sync::Arc<dyn crate::socket::SocketProtector>,
        store_path: Option<PathBuf>,
        cancellation: CancellationToken,
    ) -> Arc<Self> {
        let sample = ScanOptions::default().sample;
        Self::new(
            Arc::new(crate::netstack::scan_prober::NetstackScanProber::new(
                profile, identity, protector, sample,
            )),
            store_path,
            ScanOptions::default(),
            cancellation,
        )
    }

    /// Starts a scan round when the variant is idle. Startup rounds sample
    /// the pools; a failure first marks the variant for recovery, whose round
    /// re-verifies the known endpoints before sampling again.
    pub(crate) fn ensure_round(self: &Arc<Self>, key: PoolKey) {
        let kind = {
            let Ok(mut picker) = self.picker.lock() else {
                return;
            };
            match picker.begin_round(key) {
                Some(kind) => kind,
                None => return,
            }
        };
        let this = Arc::clone(self);
        tokio::spawn(async move {
            this.run_round(key, kind).await;
        });
    }

    async fn run_round(self: Arc<Self>, key: PoolKey, kind: RoundKind) {
        if self.cancellation.is_cancelled() {
            self.finish_round(key, &[]);
            return;
        }
        if kind == RoundKind::Recovery {
            let known = {
                let Ok(picker) = self.picker.lock() else {
                    return;
                };
                picker.known(key, RECOVERY_VERIFY_CAP)
            };
            let verified = self.scan(known, key).await;
            let adopted = {
                let Ok(mut picker) = self.picker.lock() else {
                    return;
                };
                picker.settle(key, &verified)
            };
            if let Some(endpoint) = adopted {
                self.recommend(key, endpoint);
            }
            self.persist();
        }
        let targets = self.prober.sample_targets(key);
        let results = self.scan(targets, key).await;
        self.finish_round(key, &results);
    }

    async fn scan(
        self: &Arc<Self>,
        targets: Vec<std::net::SocketAddr>,
        key: PoolKey,
    ) -> Vec<Measured> {
        let picker = Arc::clone(self);
        let on_working: Arc<dyn Fn(Measured) + Send + Sync> = Arc::new(move |endpoint| {
            let adopted = {
                let Ok(mut state) = picker.picker.lock() else {
                    return;
                };
                state.on_working(key, endpoint.clone())
            };
            if let Some(endpoint) = adopted {
                picker.recommend(key, endpoint);
            }
        });
        scan::run_round(
            targets,
            key,
            self.options,
            Arc::clone(&self.prober),
            self.cancellation.clone(),
            on_working,
        )
        .await
    }

    fn finish_round(&self, key: PoolKey, results: &[Measured]) {
        let adopted = {
            let Ok(mut picker) = self.picker.lock() else {
                return;
            };
            picker.end_round(key, results)
        };
        if let Some(endpoint) = adopted {
            self.recommend(key, endpoint);
        }
        self.persist();
    }

    /// Publishes one adoption decision; the connection code takes it once.
    fn recommend(&self, key: PoolKey, endpoint: std::net::SocketAddr) {
        self.recommendation.send_replace(Some((key, endpoint)));
    }

    /// Rule A/B/C decisions for the connection currently in use. Consuming
    /// the value clears it so the same endpoint is never re-dialled.
    pub(crate) fn take_recommendation(
        &self,
        key: PoolKey,
        current: Option<std::net::SocketAddr>,
    ) -> Option<std::net::SocketAddr> {
        let value = *self.recommendation.borrow();
        match value {
            Some((recommended, endpoint)) if recommended == key && Some(endpoint) != current => {
                self.recommendation.send_replace(None);
                Some(endpoint)
            }
            _ => None,
        }
    }

    /// Live candidates ranked for a connection attempt.
    pub(crate) fn suggest(&self, key: PoolKey) -> Vec<std::net::SocketAddr> {
        self.picker
            .lock()
            .map(|picker| picker.suggest(key))
            .unwrap_or_default()
    }

    /// Registers the endpoint a successful connection used.
    pub(crate) fn note_connected(&self, key: PoolKey, endpoint: std::net::SocketAddr) {
        if let Ok(mut picker) = self.picker.lock() {
            picker.note_connected(key, endpoint);
        }
    }

    /// A switch candidate failed: drop it from the pool without touching the
    /// connection in use.
    pub(crate) fn drop_candidate(&self, key: PoolKey, endpoint: std::net::SocketAddr) {
        if let Ok(mut picker) = self.picker.lock() {
            picker.drop_candidate(key, endpoint);
        }
    }

    /// The session in use died: drop it, then refill the pool with a
    /// recovery round.
    pub(crate) fn session_failed(self: &Arc<Self>, key: PoolKey) {
        if let Ok(mut picker) = self.picker.lock() {
            picker.session_failed(key);
        }
        self.ensure_round(key);
    }

    fn persist(&self) {
        let Some(path) = self.store_path.as_deref() else {
            return;
        };
        let snapshot = match self.picker.lock() {
            Ok(picker) => picker.snapshot(),
            Err(_) => return,
        };
        let mut document: BTreeMap<&'static str, Vec<String>> = BTreeMap::new();
        for (key, endpoint) in snapshot {
            document
                .entry(key.file_key())
                .or_default()
                .push(endpoint.to_string());
        }
        let Ok(encoded) = serde_json::to_vec_pretty(&document) else {
            return;
        };
        let temporary = path.with_extension("json.tmp");
        if std::fs::write(&temporary, encoded).is_ok() {
            let _ = std::fs::rename(&temporary, path);
        }
    }
}

type Measured = crate::picker::MeasuredEndpoint;

/// Reads the persisted pools; unreadable or malformed files start empty.
fn load_store(path: &Path) -> Vec<(PoolKey, std::net::SocketAddr)> {
    let Ok(bytes) = std::fs::read(path) else {
        return Vec::new();
    };
    let Ok(document) = serde_json::from_slice::<BTreeMap<String, Vec<String>>>(&bytes) else {
        return Vec::new();
    };
    let mut entries = Vec::new();
    for (key, endpoints) in document {
        let Some(key) = PoolKey::from_file_key(&key) else {
            continue;
        };
        for endpoint in endpoints {
            if let Ok(endpoint) = endpoint.parse() {
                entries.push((key, endpoint));
            }
        }
    }
    entries
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::scan::{ProbeClass, ProbeResult};
    use std::net::SocketAddr;
    use std::sync::atomic::{AtomicUsize, Ordering};
    use usque_core::Transport;

    struct FakeProber {
        targets: Vec<SocketAddr>,
        working: Vec<SocketAddr>,
        probes: AtomicUsize,
    }

    #[async_trait::async_trait]
    impl ScanProber for FakeProber {
        fn sample_targets(&self, _key: PoolKey) -> Vec<SocketAddr> {
            self.targets.clone()
        }

        async fn probe(
            &self,
            _key: PoolKey,
            endpoint: SocketAddr,
            _budget: std::time::Duration,
        ) -> ProbeResult {
            self.probes.fetch_add(1, Ordering::SeqCst);
            let class = if self.working.contains(&endpoint) {
                ProbeClass::Working
            } else {
                ProbeClass::Failed
            };
            ProbeResult {
                endpoint,
                class,
                colo: Some("SJC".to_owned()),
                loss: 0.0,
                tun_ping: Some(std::time::Duration::from_millis(60)),
                conn: Some(std::time::Duration::from_millis(80)),
                measured: true,
            }
        }
    }

    fn endpoint(last: u8) -> SocketAddr {
        format!("162.159.199.{last}:443").parse().unwrap()
    }

    fn picker(
        targets: Vec<SocketAddr>,
        working: Vec<SocketAddr>,
        store: Option<PathBuf>,
    ) -> Arc<EndpointPicker> {
        EndpointPicker::new(
            Arc::new(FakeProber {
                targets,
                working,
                probes: AtomicUsize::new(0),
            }),
            store,
            ScanOptions {
                attempts: 1,
                ..ScanOptions::default()
            },
            CancellationToken::new(),
        )
    }

    #[tokio::test]
    async fn a_startup_round_samples_the_pools_and_recommends_the_lowest_latency() {
        let picker = picker(
            vec![endpoint(1), endpoint(2)],
            vec![endpoint(1), endpoint(2)],
            None,
        );
        let mut recommendation = picker.recommendation.subscribe();
        picker.ensure_round(PoolKey::ConnectIp(Transport::Http3));
        let chosen = tokio::time::timeout(std::time::Duration::from_secs(5), async move {
            loop {
                if recommendation.borrow().is_some() {
                    return *recommendation.borrow();
                }
                if recommendation.changed().await.is_err() {
                    return None;
                }
            }
        })
        .await
        .expect("round finishes")
        .expect("a working endpoint is recommended");
        assert_eq!(
            chosen.1,
            endpoint(1),
            "both measure the same; the first wins the tie"
        );
        tokio::time::timeout(std::time::Duration::from_secs(5), async {
            while picker.suggest(PoolKey::ConnectIp(Transport::Http3)).len() < 2 {
                tokio::time::sleep(std::time::Duration::from_millis(5)).await;
            }
        })
        .await
        .expect("the round merges both endpoints");
        assert_eq!(
            picker.suggest(PoolKey::ConnectIp(Transport::Http3)),
            vec![endpoint(1), endpoint(2)],
            "the pool remembers both for the next connection",
        );
    }

    #[tokio::test]
    async fn recommendations_are_taken_once() {
        let key = PoolKey::ConnectIp(Transport::Http3);
        let picker = picker(vec![endpoint(1)], vec![endpoint(1)], None);
        picker.ensure_round(key);
        tokio::time::timeout(std::time::Duration::from_secs(5), async {
            while picker.recommendation.borrow().is_none() {
                tokio::time::sleep(std::time::Duration::from_millis(5)).await;
            }
        })
        .await
        .expect("round adopts an endpoint");
        assert_eq!(
            picker.take_recommendation(key, Some(endpoint(9))),
            Some(endpoint(1))
        );
        assert_eq!(picker.take_recommendation(key, Some(endpoint(9))), None);
        assert_eq!(
            picker.take_recommendation(key, Some(endpoint(1))),
            None,
            "the endpoint already in use is never re-dialled",
        );
    }

    #[tokio::test]
    async fn a_failure_opens_a_recovery_round_that_re_verifies_the_pool() {
        let key = PoolKey::ConnectIp(Transport::Http3);
        let prober = Arc::new(FakeProber {
            targets: vec![endpoint(7)],
            working: vec![endpoint(1)],
            probes: AtomicUsize::new(0),
        });
        let picker = EndpointPicker::new(
            prober.clone(),
            None,
            ScanOptions {
                attempts: 1,
                ..ScanOptions::default()
            },
            CancellationToken::new(),
        );
        picker.note_connected(key, endpoint(1));
        picker.session_failed(key);
        tokio::time::timeout(std::time::Duration::from_secs(5), async {
            while picker.recommendation.borrow().is_none() {
                tokio::time::sleep(std::time::Duration::from_millis(5)).await;
            }
        })
        .await
        .expect("the recovery round adopts a survivor");
        assert_eq!(
            picker
                .recommendation
                .borrow()
                .as_ref()
                .map(|(_, endpoint)| *endpoint),
            Some(endpoint(1)),
            "the re-verified endpoint returns",
        );
        assert!(
            prober.probes.load(Ordering::SeqCst) >= 2,
            "the recovery round verified the known endpoint and sampled the pools",
        );
    }

    #[tokio::test]
    async fn the_pool_round_trips_through_the_state_file() {
        let directory = tempfile::tempdir().expect("temporary directory");
        let path = directory.path().join("endpoint_pool.json");
        let key = PoolKey::ConnectIp(Transport::Http2);
        {
            let picker = picker(vec![endpoint(3)], vec![endpoint(3)], Some(path.clone()));
            picker.ensure_round(key);
            tokio::time::timeout(std::time::Duration::from_secs(5), async {
                while picker.recommendation.borrow().is_none() {
                    tokio::time::sleep(std::time::Duration::from_millis(5)).await;
                }
            })
            .await
            .expect("round adopts an endpoint");
        }
        let restored = load_store(&path);
        assert!(restored.contains(&(key, endpoint(3))));
        let reopened = picker(Vec::new(), Vec::new(), Some(path));
        assert_eq!(
            reopened.suggest(key),
            vec![endpoint(3)],
            "a fresh process starts warm",
        );
    }
}

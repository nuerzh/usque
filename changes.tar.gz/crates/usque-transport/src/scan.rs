//! Active endpoint probing (handshake, `/meta` validation and the in-tunnel
//! durability burst), ported from the Go usque `internal/scan`. The probing
//! approach originates from github.com/vernette/warpscout (MIT): dial a
//! CONNECT-IP tunnel through a candidate address, verify it by fetching
//! Cloudflare's `/meta` through the tunnel, and weed out endpoints a DPI box
//! tears down mid-stream with an in-tunnel HTTP burst.
//!
//! The transport-specific probing (building the throwaway tunnel) lives in
//! the mode that owns it; this module owns target generation, round
//! scheduling, retries and the burst's statistics.
use std::collections::BTreeMap;
use std::net::{Ipv6Addr, SocketAddr};
use std::sync::Arc;
use std::time::Duration;

use async_trait::async_trait;
use tokio::task::JoinSet;
use tokio_util::sync::CancellationToken;
use usque_core::{AutomaticEndpointPolicy, Transport};

use crate::picker::{MeasuredEndpoint, PoolKey};

/// The Cloudflare endpoint whose body proves the tunnel carries data, and the
/// burst target. Without a `Referer` it answers 403.
pub(crate) const META_URL: &str = "https://speed.cloudflare.com/meta";
pub(crate) const META_REFERER: &str = "https://speed.cloudflare.com";
pub(crate) const META_LIMIT: usize = 4096;

/// A DPI teardown shows up as a trailing run of failed probes: the tunnel
/// passed data, then was cut mid-stream and never recovered. Sporadic single
/// failures are loss, not teardown.
pub(crate) const TORN_TAIL_FAILS: usize = 3;

/// Keep the burst long enough that one stray drop cannot look like a
/// teardown, and long enough that a mid-burst death is visible.
pub(crate) const DEFAULT_TUN_PINGS: usize = 10;
pub(crate) const MIN_TUN_PINGS: usize = 5;

#[derive(Clone, Copy, Debug)]
pub(crate) struct ScanOptions {
    /// Bounds one handshake/meta/burst round.
    pub(crate) timeout: Duration,
    /// Number of concurrent probe tunnels.
    pub(crate) jobs: usize,
    /// How many addresses to draw from each pool.
    pub(crate) sample: usize,
    /// Per-endpoint dial retries: the same endpoint often answers one attempt
    /// and times out the next, so a single failure says nothing.
    pub(crate) attempts: u32,
    /// In-tunnel durability burst length; 0 disables the burst.
    pub(crate) tun_pings: usize,
}

impl Default for ScanOptions {
    fn default() -> Self {
        Self {
            timeout: Duration::from_secs(2),
            jobs: 10,
            sample: 5,
            attempts: 3,
            tun_pings: DEFAULT_TUN_PINGS,
        }
    }
}

impl ScanOptions {
    pub(crate) fn normalized(mut self) -> Self {
        if self.timeout.is_zero() {
            self.timeout = Duration::from_secs(2);
        }
        if self.jobs == 0 {
            self.jobs = 10;
        }
        if self.sample == 0 {
            self.sample = 5;
        }
        if self.attempts == 0 {
            self.attempts = 3;
        }
        if self.tun_pings != 0 && self.tun_pings < MIN_TUN_PINGS {
            self.tun_pings = MIN_TUN_PINGS;
        }
        self
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(crate) enum ProbeClass {
    /// Never completed handshake plus `/meta`.
    Failed,
    /// Passed data, then cut mid-stream.
    Torn,
    /// Passed every check.
    Working,
}

#[derive(Clone, Debug)]
pub(crate) struct ProbeResult {
    pub(crate) endpoint: SocketAddr,
    pub(crate) class: ProbeClass,
    pub(crate) colo: Option<String>,
    pub(crate) loss: f32,
    pub(crate) tun_ping: Option<Duration>,
    pub(crate) conn: Option<Duration>,
    pub(crate) measured: bool,
}

impl ProbeResult {
    pub(crate) fn failed(endpoint: SocketAddr) -> Self {
        Self {
            endpoint,
            class: ProbeClass::Failed,
            colo: None,
            loss: 0.0,
            tun_ping: None,
            conn: None,
            measured: false,
        }
    }

    pub(crate) fn into_endpoint(self) -> Option<MeasuredEndpoint> {
        match self.class {
            ProbeClass::Working => Some(MeasuredEndpoint {
                endpoint: self.endpoint,
                colo: self.colo,
                loss: self.loss,
                tun_ping: self.tun_ping,
                conn: self.conn,
                measured: self.measured,
            }),
            ProbeClass::Failed | ProbeClass::Torn => None,
        }
    }
}

/// One probe source: draws the round's sample targets from the pools and
/// probes each endpoint (handshake, `/meta` and the durability burst).
#[async_trait]
pub(crate) trait ScanProber: Send + Sync + 'static {
    fn sample_targets(&self, key: PoolKey) -> Vec<SocketAddr>;
    async fn probe(&self, key: PoolKey, endpoint: SocketAddr, budget: Duration) -> ProbeResult;
}

/// Pool sampling for one variant. H3 (QUIC) is served from the `::1`/`::2`
/// representatives of each block; CONNECT-IP over TCP+TLS answers across
/// wider ranges, so each H2 prefix draws a bounded random sample seeded with
/// the same representatives.
pub(crate) fn sample_targets(
    policy: AutomaticEndpointPolicy,
    transport: Transport,
    sample: usize,
) -> Vec<SocketAddr> {
    if transport == Transport::Http3 {
        return policy.h3_candidates();
    }
    let seeds = AutomaticEndpointPolicy {
        udp: true,
        ..policy
    }
    .h3_candidates();
    let mut targets = Vec::new();

    let mut prefixes: BTreeMap<u8, Vec<SocketAddr>> = BTreeMap::new();
    for endpoint in policy.h2_ipv4_candidates() {
        let SocketAddr::V4(v4) = endpoint else {
            continue;
        };
        prefixes
            .entry(v4.ip().octets()[2])
            .or_default()
            .push(endpoint);
    }
    for (_, mut group) in prefixes {
        let mut selected = Vec::new();
        for seed in &seeds {
            if let Some(index) = group.iter().position(|entry| entry == seed) {
                selected.push(group.swap_remove(index));
            }
        }
        while selected.len() < sample && !group.is_empty() {
            let index = random_index(group.len());
            selected.push(group.swap_remove(index));
        }
        targets.extend(selected);
    }

    for prefix in policy.ipv6_prefixes() {
        let mut selected = Vec::new();
        for seed in &seeds {
            let in_prefix = match seed.ip() {
                std::net::IpAddr::V6(ip) => u128::from(ip) >> 80 == u128::from(prefix) >> 80,
                std::net::IpAddr::V4(_) => false,
            };
            if seed.is_ipv6() && in_prefix {
                selected.push(*seed);
            }
        }
        while selected.len() < sample {
            selected.push(SocketAddr::new(
                Ipv6Addr::from(random_host(prefix)).into(),
                policy.port,
            ));
        }
        targets.extend(selected);
    }

    targets.sort_unstable();
    targets.dedup();
    targets
}

fn random_index(len: usize) -> usize {
    let mut bytes = [0_u8; 8];
    let _ = boring::rand::rand_bytes(&mut bytes);
    (u64::from_le_bytes(bytes) % len as u64) as usize
}

/// A random address inside a /48 pool: the prefix keeps the high 48 bits and
/// the remaining 80 bits are randomised.
fn random_host(prefix: Ipv6Addr) -> Ipv6Addr {
    let mut random = [0_u8; 16];
    let _ = boring::rand::rand_bytes(&mut random);
    let suffix = u128::from_be_bytes(random) & ((1_u128 << 80) - 1);
    Ipv6Addr::from(u128::from(prefix) | suffix)
}

/// One round: probe every target with bounded concurrency, stream each
/// working endpoint to `on_working` as soon as it passes, and return the
/// working set ranked by loss, then latency, then address.
pub(crate) async fn run_round(
    targets: Vec<SocketAddr>,
    key: PoolKey,
    options: ScanOptions,
    prober: Arc<dyn ScanProber>,
    cancellation: CancellationToken,
    on_working: Arc<dyn Fn(MeasuredEndpoint) + Send + Sync>,
) -> Vec<MeasuredEndpoint> {
    let options = options.normalized();
    if targets.is_empty() {
        return Vec::new();
    }
    let semaphore = Arc::new(tokio::sync::Semaphore::new(options.jobs));
    let mut tasks: JoinSet<ProbeResult> = JoinSet::new();
    for target in targets {
        let semaphore = Arc::clone(&semaphore);
        let prober = Arc::clone(&prober);
        let cancellation = cancellation.clone();
        tasks.spawn(async move {
            let Ok(_permit) = semaphore.acquire_owned().await else {
                return ProbeResult::failed(target);
            };
            probe_one(target, key, options, prober, cancellation).await
        });
    }

    let mut working = Vec::new();
    loop {
        let joined = tokio::select! {
            biased;
            _ = cancellation.cancelled() => {
                tasks.shutdown().await;
                break;
            }
            joined = tasks.join_next() => joined,
        };
        match joined {
            Some(Ok(result)) => match result.class {
                ProbeClass::Working => {
                    if let Some(endpoint) = result.clone().into_endpoint() {
                        on_working(endpoint.clone());
                        working.push(endpoint);
                    }
                }
                ProbeClass::Failed | ProbeClass::Torn => {}
            },
            Some(Err(error)) => tracing::debug!(%error, "endpoint probe task failed"),
            None => break,
        }
    }

    working.sort_by(ranked_before);
    working
}

fn ranked_before(left: &MeasuredEndpoint, right: &MeasuredEndpoint) -> std::cmp::Ordering {
    if left.loss != right.loss {
        return left
            .loss
            .partial_cmp(&right.loss)
            .unwrap_or(std::cmp::Ordering::Equal);
    }
    match (left.latency(), right.latency()) {
        (Some(l), Some(r)) if l != r => l.cmp(&r),
        (Some(_), None) => std::cmp::Ordering::Less,
        (None, Some(_)) => std::cmp::Ordering::Greater,
        _ => left.endpoint.cmp(&right.endpoint),
    }
}

/// Handshake, `/meta` and burst with the per-endpoint dial retries: one
/// attempt that completes any stage beyond the handshake answers the round.
async fn probe_one(
    target: SocketAddr,
    key: PoolKey,
    options: ScanOptions,
    prober: Arc<dyn ScanProber>,
    cancellation: CancellationToken,
) -> ProbeResult {
    for _ in 0..options.attempts {
        if cancellation.is_cancelled() {
            return ProbeResult::failed(target);
        }
        let attempt =
            tokio::time::timeout(options.timeout, prober.probe(key, target, options.timeout)).await;
        match attempt {
            Ok(result) if result.class != ProbeClass::Failed => return result,
            _ => continue,
        }
    }
    ProbeResult::failed(target)
}

/// The burst statistics over one keep-alive connection: `conn` is the first
/// request (including setup), `tun_ping` the median of the follow-ups, and
/// `torn` a trailing run of at least [`TORN_TAIL_FAILS`] failures (or every
/// attempted probe failing right after the `/meta` fetch succeeded).
#[derive(Clone, Copy, Debug, PartialEq)]
pub(crate) struct BurstSample {
    pub(crate) conn: Option<Duration>,
    pub(crate) tun_ping: Option<Duration>,
    pub(crate) loss: f32,
    pub(crate) torn: bool,
}

/// `outcomes` are the burst's requests in order: `Some(elapsed)` succeeded,
/// `None` failed. Requests the deadline prevented from starting are absent.
pub(crate) fn burst_sample(outcomes: &[Option<Duration>]) -> BurstSample {
    let total = outcomes.len();
    let got = outcomes.iter().filter(|outcome| outcome.is_some()).count();
    let steady: Vec<Duration> = outcomes.iter().skip(1).flatten().copied().collect();
    let torn = is_torn_down(outcomes) || (total > 0 && got == 0);
    BurstSample {
        conn: outcomes.first().copied().flatten(),
        tun_ping: median(&steady),
        loss: if total == 0 {
            0.0
        } else {
            (total - got) as f32 / total as f32
        },
        torn,
    }
}

/// A real teardown stays dead across both bursts; transient loss does not,
/// so the second burst's numbers are reported when the first was noise.
pub(crate) fn durability(first: BurstSample, second: BurstSample) -> BurstSample {
    if first.torn && !second.torn {
        second
    } else {
        first
    }
}

/// The middle sample (mean of the two middle ones for an even count), so one
/// slow probe cannot drag the reading up.
fn median(samples: &[Duration]) -> Option<Duration> {
    if samples.is_empty() {
        return None;
    }
    let mut sorted = samples.to_vec();
    sorted.sort_unstable();
    let count = sorted.len();
    Some(if count % 2 == 1 {
        sorted[count / 2]
    } else {
        (sorted[count / 2 - 1] + sorted[count / 2]) / 2
    })
}

fn is_torn_down(outcomes: &[Option<Duration>]) -> bool {
    if outcomes.len() < TORN_TAIL_FAILS {
        return false;
    }
    outcomes[outcomes.len() - TORN_TAIL_FAILS..]
        .iter()
        .all(Option::is_none)
}

#[cfg(test)]
mod tests {
    use std::collections::{HashMap, HashSet};

    use super::*;

    fn policy(pool: usque_core::EndpointPool) -> AutomaticEndpointPolicy {
        AutomaticEndpointPolicy {
            pool,
            port: 443,
            ipv4: true,
            ipv6: true,
            tcp: true,
            udp: true,
        }
    }

    #[test]
    fn burst_sample_reports_conn_median_loss_and_torn_tail() {
        let sample = burst_sample(&[
            Some(Duration::from_millis(90)),
            Some(Duration::from_millis(40)),
            Some(Duration::from_millis(60)),
            Some(Duration::from_millis(50)),
            None,
            None,
            None,
        ]);
        assert_eq!(sample.conn, Some(Duration::from_millis(90)));
        assert_eq!(sample.tun_ping, Some(Duration::from_millis(50)));
        assert!((sample.loss - 3.0_f32 / 7.0).abs() < f32::EPSILON);
        assert!(
            sample.torn,
            "a trailing run of three failures is a teardown"
        );
    }

    #[test]
    fn a_middle_failure_is_loss_and_a_clean_burst_is_not_torn() {
        let sample = burst_sample(&[
            Some(Duration::from_millis(10)),
            Some(Duration::from_millis(20)),
            None,
            Some(Duration::from_millis(30)),
            Some(Duration::from_millis(40)),
            Some(Duration::from_millis(50)),
            Some(Duration::from_millis(60)),
        ]);
        assert!(!sample.torn);
        assert!((sample.loss - 1.0_f32 / 7.0).abs() < f32::EPSILON);
    }

    #[test]
    fn a_burst_where_every_attempt_failed_after_meta_counts_as_torn() {
        let sample = burst_sample(&[None, None]);
        assert!(sample.torn);
        assert!(sample.conn.is_none());
        assert_eq!(sample.tun_ping, None);
    }

    #[test]
    fn durability_prefers_the_second_burst_only_when_it_recovers() {
        let torn = BurstSample {
            conn: None,
            tun_ping: None,
            loss: 1.0,
            torn: true,
        };
        let clean = BurstSample {
            conn: Some(Duration::from_millis(30)),
            tun_ping: Some(Duration::from_millis(25)),
            loss: 0.0,
            torn: false,
        };
        assert_eq!(
            durability(torn, clean),
            clean,
            "transient loss is renumbered"
        );
        assert_eq!(
            durability(clean, torn),
            clean,
            "a recovered first burst stands"
        );
        assert_eq!(durability(torn, torn), torn, "a real teardown stays dead");
    }

    #[test]
    fn h3_sampling_returns_every_permitted_representative() {
        let free = sample_targets(policy(usque_core::EndpointPool::Free), Transport::Http3, 5);
        assert_eq!(free.len(), 8);
        let plus = sample_targets(
            policy(usque_core::EndpointPool::WarpPlus),
            Transport::Http3,
            5,
        );
        assert_eq!(plus.len(), 4);
        assert!(free.iter().all(|endpoint| endpoint.port() == 443));
    }

    #[test]
    fn h2_sampling_draws_the_sample_size_from_every_prefix_and_keeps_seeds() {
        let targets = sample_targets(policy(usque_core::EndpointPool::Free), Transport::Http2, 5);
        let mut per_prefix: BTreeMap<u8, usize> = BTreeMap::new();
        let mut v6 = 0;
        for endpoint in &targets {
            if let SocketAddr::V4(v4) = endpoint {
                *per_prefix.entry(v4.ip().octets()[2]).or_default() += 1;
            } else {
                v6 += 1;
            }
        }
        assert_eq!(per_prefix, BTreeMap::from([(198, 5), (199, 5)]));
        assert_eq!(v6, 10, "two /48 pools at the sample size");
        assert!(targets.contains(&"162.159.198.1:443".parse().unwrap()));
        assert!(targets.contains(&"162.159.199.2:443".parse().unwrap()));
        assert!(targets.contains(&"[2606:4700:103::1]:443".parse().unwrap()));
        let unique: HashSet<_> = targets.iter().collect();
        assert_eq!(unique.len(), targets.len(), "no duplicates");
    }

    #[test]
    fn h2_sampling_respects_the_pool_and_port_policy() {
        let mut policy = policy(usque_core::EndpointPool::WarpPlus);
        policy.port = 8443;
        let targets = sample_targets(policy, Transport::Http2, 3);
        assert!(targets.iter().all(|endpoint| endpoint.port() == 8443));
        assert!(
            !targets
                .iter()
                .any(|endpoint| endpoint.ip().to_string().starts_with("162.159.198."))
        );
    }

    struct FakeProber {
        answers: Vec<(SocketAddr, ProbeClass)>,
        attempts: std::sync::Mutex<HashMap<SocketAddr, usize>>,
    }

    #[async_trait]
    impl ScanProber for FakeProber {
        fn sample_targets(&self, _key: PoolKey) -> Vec<SocketAddr> {
            Vec::new()
        }

        async fn probe(
            &self,
            _key: PoolKey,
            endpoint: SocketAddr,
            _budget: Duration,
        ) -> ProbeResult {
            *self.attempts.lock().unwrap().entry(endpoint).or_default() += 1;
            let class = self
                .answers
                .iter()
                .find(|(answer, _)| *answer == endpoint)
                .map(|(_, class)| *class)
                .unwrap_or(ProbeClass::Failed);
            let mut result = ProbeResult {
                endpoint,
                class,
                ..ProbeResult::failed(endpoint)
            };
            if class == ProbeClass::Working {
                result.measured = true;
                result.tun_ping = Some(Duration::from_millis(40));
                result.colo = Some("SJC".to_owned());
            }
            result
        }
    }

    #[tokio::test]
    async fn run_round_retries_failures_streams_working_endpoints_and_skips_torn() {
        let working_addr: SocketAddr = "162.159.199.1:443".parse().unwrap();
        let torn_addr: SocketAddr = "162.159.199.2:443".parse().unwrap();
        let dead_addr: SocketAddr = "162.159.199.3:443".parse().unwrap();
        let prober = Arc::new(FakeProber {
            answers: vec![
                (working_addr, ProbeClass::Working),
                (torn_addr, ProbeClass::Torn),
            ],
            attempts: std::sync::Mutex::new(HashMap::new()),
        });
        let streamed = Arc::new(std::sync::Mutex::new(Vec::new()));
        let streamed_probe = Arc::clone(&streamed);
        let results = run_round(
            vec![working_addr, torn_addr, dead_addr],
            PoolKey::ConnectIp(Transport::Http3),
            ScanOptions {
                attempts: 3,
                jobs: 2,
                ..ScanOptions::default()
            },
            prober.clone(),
            CancellationToken::new(),
            Arc::new(move |endpoint: MeasuredEndpoint| {
                streamed_probe.lock().unwrap().push(endpoint.endpoint);
            }),
        )
        .await;
        assert_eq!(results.len(), 1);
        assert_eq!(results[0].endpoint, working_addr);
        assert_eq!(*streamed.lock().unwrap(), vec![working_addr]);
        let attempts = prober.attempts.lock().unwrap();
        assert_eq!(attempts[&working_addr], 1, "a passing dial needs no retry");
        assert_eq!(
            attempts[&torn_addr], 1,
            "a torn endpoint completed its dial"
        );
        assert_eq!(attempts[&dead_addr], 3, "a dead endpoint is retried");
    }

    #[tokio::test]
    async fn run_round_stops_on_cancellation() {
        let prober = Arc::new(FakeProber {
            answers: Vec::new(),
            attempts: std::sync::Mutex::new(HashMap::new()),
        });
        let cancellation = CancellationToken::new();
        cancellation.cancel();
        let targets = (0..4)
            .map(|last| format!("162.159.199.{last}:443").parse().unwrap())
            .collect();
        let results = run_round(
            targets,
            PoolKey::ConnectIp(Transport::Http3),
            ScanOptions::default(),
            prober,
            cancellation,
            Arc::new(|_| {}),
        )
        .await;
        assert!(results.is_empty());
    }

    #[test]
    fn normalized_options_enforce_go_defaults_and_minimums() {
        let options = ScanOptions {
            timeout: Duration::ZERO,
            jobs: 0,
            sample: 0,
            attempts: 0,
            tun_pings: 3,
        }
        .normalized();
        assert_eq!(options.timeout, Duration::from_secs(2));
        assert_eq!(options.jobs, 10);
        assert_eq!(options.sample, 5);
        assert_eq!(options.attempts, 3);
        assert_eq!(options.tun_pings, MIN_TUN_PINGS);
    }
}

//! CONNECT-IP prober for [`crate::picker`]: dial a throwaway tunnel through a
//! candidate endpoint, fetch `/meta` to prove it carries data, then run the
//! in-tunnel burst that detects a DPI teardown.
use std::net::SocketAddr;

use bytes::Bytes;
use tokio::time::Instant;
use tokio_util::sync::CancellationToken;
use usque_core::{AddressFamily, AutomaticEndpointPolicy, Profile, Transport};

use crate::geo_direct::GeoDirectPolicy;
use crate::h2::MasqueTlsIdentity;
use crate::picker::PoolKey;
use crate::scan::{
    BurstSample, ProbeClass, ProbeResult, ScanProber, burst_sample, durability, sample_targets,
};
use crate::socket::SocketProtector;
use crate::telemetry::ConnectionTelemetry;
use crate::tunnel::MasqueTunnel;

/// How long the throwaway tunnel may take to come up and answer `/meta`.
const PROBE_BUDGET: std::time::Duration = std::time::Duration::from_secs(3);

pub(crate) struct NetstackScanProber {
    profile: Profile,
    identity: MasqueTlsIdentity,
    protector: std::sync::Arc<dyn SocketProtector>,
    policy: AutomaticEndpointPolicy,
    sample: usize,
}

impl NetstackScanProber {
    pub(crate) fn new(
        profile: &Profile,
        identity: &MasqueTlsIdentity,
        protector: std::sync::Arc<dyn SocketProtector>,
        sample: usize,
    ) -> Self {
        let policy = AutomaticEndpointPolicy::for_profile(profile, identity.endpoint_pool());
        Self {
            profile: profile.clone(),
            identity: identity.clone(),
            protector,
            policy,
            sample,
        }
    }
}

#[async_trait::async_trait]
impl ScanProber for NetstackScanProber {
    fn sample_targets(&self, key: PoolKey) -> Vec<SocketAddr> {
        sample_targets(self.policy, key.transport(), self.sample)
    }

    async fn probe(
        &self,
        key: PoolKey,
        endpoint: SocketAddr,
        budget: std::time::Duration,
    ) -> ProbeResult {
        let transport = key.transport();
        let budget = budget.min(PROBE_BUDGET);
        match dial(
            &self.profile,
            &self.identity,
            self.protector.clone(),
            transport,
            endpoint,
        )
        .await
        {
            Ok((tunnel, identity, family)) => {
                let sample = measure(
                    &self.profile,
                    &identity,
                    self.protector.clone(),
                    tunnel,
                    transport,
                    family,
                    budget,
                )
                .await;
                to_probe_result(endpoint, sample)
            }
            Err(_) => ProbeResult::failed(endpoint),
        }
    }
}

async fn dial(
    profile: &Profile,
    identity: &MasqueTlsIdentity,
    protector: std::sync::Arc<dyn SocketProtector>,
    transport: Transport,
    endpoint: SocketAddr,
) -> Result<(MasqueTunnel, MasqueTlsIdentity, AddressFamily), ()> {
    let family = if endpoint.is_ipv4() {
        AddressFamily::Ipv4
    } else {
        AddressFamily::Ipv6
    };
    let telemetry = ConnectionTelemetry::default();
    let tunnel = super::connect_endpoint(
        transport,
        super::EndpointCandidate::new(endpoint, family),
        &profile.endpoint.sni,
        identity,
        usize::from(profile.mtu),
        profile.congestion_control,
        protector,
        &telemetry,
    )
    .await
    .map_err(|_| ())?;
    Ok((tunnel, identity.clone(), family))
}

#[expect(
    clippy::too_many_arguments,
    reason = "burst measurement threads profile, identity, I/O, and budget as one probe unit"
)]
async fn measure(
    profile: &Profile,
    identity: &MasqueTlsIdentity,
    protector: std::sync::Arc<dyn SocketProtector>,
    tunnel: MasqueTunnel,
    transport: Transport,
    family: AddressFamily,
    budget: std::time::Duration,
) -> Option<BurstSample> {
    let cancellation = CancellationToken::new();
    let deadline = Instant::now() + budget;
    let monitor = super::ManagedTunnelMonitor::for_scan(transport, family);
    let geo_policy = std::sync::Arc::new(GeoDirectPolicy::disabled());
    let (mut stack, pipe) = super::PacketStack::start_detached(
        profile,
        (identity.assigned_ipv4, identity.assigned_ipv6),
        &monitor,
        &cancellation,
        protector,
        geo_policy,
    )
    .await
    .ok()?;
    let network = crate::internal_network::InternalNetwork::for_stack(
        profile,
        &stack,
        identity.assigned_ipv4,
        identity.assigned_ipv6,
    );
    let pump = pump(tunnel, pipe, cancellation.clone());
    tokio::pin!(pump);
    let burst = burst(&network, &cancellation, deadline);
    tokio::pin!(burst);
    let sample = tokio::select! {
        biased;
        _ = cancellation.cancelled() => None,
        sample = &mut burst => sample,
        _ = &mut pump => None,
    };
    cancellation.cancel();
    stack.shutdown().await;
    sample
}

async fn pump(
    tunnel: MasqueTunnel,
    pipe: crate::packet_pipe::PacketPipe,
    cancellation: CancellationToken,
) {
    let (send, mut receive, driver, _control) = tunnel.into_parts();
    let mut packet_io = super::PacketIo::from_pipe(pipe);
    let pump_one = async {
        loop {
            tokio::select! {
                biased;
                _ = cancellation.cancelled() => return,
                batch = packet_io.receive_outgoing_batch() => {
                    let Some(batch) = batch else { return };
                    if send.start_owned_batch(batch).await.is_err() {
                        return;
                    }
                }
                delivered = receive.receive_batch() => {
                    let Ok(batch) = delivered else { return };
                    if !packet_io.start_incoming_batch(batch).await {
                        return;
                    }
                }
            }
        }
    };
    tokio::select! {
        biased;
        _ = cancellation.cancelled() => {}
        _ = pump_one => {}
        _ = driver.wait() => {}
    }
}

async fn burst(
    network: &crate::internal_network::InternalNetwork,
    cancellation: &CancellationToken,
    deadline: Instant,
) -> Option<BurstSample> {
    let conn = fetch(network, cancellation, deadline).await?;
    let mut outcomes = vec![Some(conn)];
    let tun_pings = crate::scan::DEFAULT_TUN_PINGS;
    for _ in 1..tun_pings {
        if cancellation.is_cancelled() {
            break;
        }
        outcomes.push(fetch(network, cancellation, deadline).await);
    }
    let first = burst_sample(&outcomes);
    if !first.torn {
        return Some(first);
    }
    let mut second_outcomes = vec![fetch(network, cancellation, deadline).await];
    for _ in 1..tun_pings {
        if cancellation.is_cancelled() {
            break;
        }
        second_outcomes.push(fetch(network, cancellation, deadline).await);
    }
    Some(durability(first, burst_sample(&second_outcomes)))
}

async fn fetch(
    network: &crate::internal_network::InternalNetwork,
    cancellation: &CancellationToken,
    deadline: Instant,
) -> Option<std::time::Duration> {
    if cancellation.is_cancelled() || Instant::now() >= deadline {
        return None;
    }
    let started = Instant::now();
    let request = network.request_https(
        crate::internal_network::InternalRequest {
            url: crate::scan::META_URL,
            method: http::Method::GET,
            headers: vec![("referer", crate::scan::META_REFERER)],
            body: Bytes::new(),
            limit: crate::scan::META_LIMIT,
            ipv6: None,
        },
        cancellation,
    );
    match tokio::time::timeout_at(deadline, request).await {
        Ok(Ok(_)) => Some(started.elapsed()),
        _ => None,
    }
}

fn to_probe_result(endpoint: SocketAddr, sample: Option<BurstSample>) -> ProbeResult {
    let Some(sample) = sample else {
        return ProbeResult::failed(endpoint);
    };
    let class = if sample.torn {
        ProbeClass::Torn
    } else {
        ProbeClass::Working
    };
    ProbeResult {
        endpoint,
        class,
        colo: None,
        loss: sample.loss,
        tun_ping: sample.tun_ping,
        conn: sample.conn,
        measured: sample.tun_ping.is_some(),
    }
}
